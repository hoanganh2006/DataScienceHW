

```python
import requests as req
import json
import openweathermapy as ow
import random
import numpy as np
from citipy import citipy
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
% matplotlib inline
```


```python
# API key and url for Open Weather Map
api_key = "c77d69add01c4b65c6e7966c305d8834"
url = "http://api.openweathermap.org/data/2.5/weather?"
```


```python
location_dict = {}
count = 0
weather_data = []
while count < 500: 
    x = random.uniform(-90.000, 90.000)
    y = random.uniform(-180.000, 180.000)
    location = citipy.nearest_city(x, y)
    city_name = location.city_name
    city_country = location.country_code
    if not city_name in location_dict:
        location_dict.update({city_name: city_country})
        # Build query URL
        query_url = url + "appid=" + api_key + "&q=" + city_name + "," + city_country
        weather = req.get(query_url)
        weather_response = req.get(query_url).json()
        weather_data.append(weather_response)
        try: 
            weather_data.remove({'cod': '404', 'message': 'city not found'})
        except: 
            pass
        count = len(weather_data)
        print(query_url)
        print(weather)
```

    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ushuaia,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=faanui,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hualmay,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=norman wells,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=avera,pf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=innisfail,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=albany,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kadoshkino,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port-de-paix,ht
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zwedru,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chuy,uy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=narsaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taolanaro,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=palabuhanratu,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=la tuque,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=coracora,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=samusu,ws
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nanortalik,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tunduru,tz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=victoria,sc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-philippe,re
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tura,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=torbay,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kapaa,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=quatre cocos,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vaini,to
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rio gallegos,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=butaritari,ki
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tiarei,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=new norfolk,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=illoqqortoormiut,gl
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=anadyr,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hobart,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=qaanaaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=severo-kurilsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=castro,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=betsiamites,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rengasdengklok,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=denpasar,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=severomuysk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mataura,pf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dingle,ie
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bethel,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yellowknife,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hay river,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sioux lookout,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=turukhansk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cape town,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mahebourg,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rodrigues alves,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mayskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rikitea,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila velha,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gebre guracha,et
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hambantota,lk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bluff,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ribeira grande,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tuktoyaktuk,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tuy hoa,vn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=khatanga,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barcelos,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nikel,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ilulissat,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cherskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ostrovnoy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sao filipe,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=high level,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=iskateley,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bathsheba,bb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=acapulco,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ballina,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa marta,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jamestown,sh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=benjamin hill,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pitimbu,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=airai,pw
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saldanha,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nome,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=belushya guba,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mayya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tuatapere,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zaragoza,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=verkhnyaya inta,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=uni,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bilibino,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tateyama,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lac du bonnet,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=liberal,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto ayora,ec
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=avarua,ck
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port macquarie,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aljezur,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port alfred,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=berthierville,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=thompson,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mar del plata,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=seymchan,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shaunavon,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tara,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chokurdakh,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=busselton,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hobyo,so
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tiksi,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=longyearbyen,sj
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mancora,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=carnarvon,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint anthony,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ciudad bolivar,ve
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san francisco,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saskylakh,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=potrero del llano,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port lincoln,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=te anau,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=opuwo,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mount isa,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=boyolangu,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=provideniya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cap malheureux,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hermanus,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=del rio,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kununurra,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fortuna,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kupang,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=punta arenas,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=asau,tv
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lompoc,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nikolskoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aflu,dz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port hardy,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=caronport,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tortoli,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bonthe,sl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barrow,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tasiilaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=voloshka,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=makakilo city,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=flinders,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bambous virieux,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fort nelson,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bud,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=general salgado,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grindavik,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jiehu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tsihombe,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila franca do campo,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=juan lacaze,uy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cabo san lucas,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabiauea,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san patricio,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=trairi,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=waw,sd
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=upernavik,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cam pha,vn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=danshui,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=roald,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ixtapa,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=obluche,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vardo,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kalengwa,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=arraial do cabo,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=naron,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mys shmidta,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=maues,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=galegos,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kegayli,uz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beni suef,eg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vostok,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vestmannaeyjar,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=deputatskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gympie,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=quelimane,mz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marawi,sd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kpalime,tg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san policarpo,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=viseu,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hailar,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sentyabrskiy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cayenne,gf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pevek,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto colombia,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=natal,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bundaberg,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mehamn,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=voh,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nioro,ml
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=otradnoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=iqaluit,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nuevo progreso,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atar,mr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=wad rawah,sd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mount gambier,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-malo,fr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bandarbeyla,so
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ouango,cf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=general roca,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atuona,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=banda aceh,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lavrentiya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=souillac,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bubaque,gw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=darlawn,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san ramon,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=humaita,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nizhniy tsasuchey,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kenai,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bengkulu,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kokopo,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shingu,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kigorobya,ug
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mbandaka,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kurchum,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=malhador,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint george,bm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tucuma,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=todos santos,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=riyadh,sa
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=asekeyevo,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mazara del vallo,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=utiroa,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kavaratti,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mandera,ke
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=clyde river,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=byron bay,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=amderma,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hithadhoo,mv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=auray,fr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=karaton,kz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zhigansk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luau,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=honiara,sb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vaitupu,wf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lanzhou,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pangoa,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mumbwa,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ancud,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pryozerne,ua
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jasper,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beringovskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand gaube,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saravan,la
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cidreira,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dukat,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yar-sale,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mogadishu,so
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=okhotsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bredasdorp,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=murdochville,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muzhi,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rawson,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=flin flon,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=strathmore,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=la palma,pa
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aksarka,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=duluth,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=piracicaba,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ponta do sol,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nizhneyansk,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kaitangata,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=margate,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bracebridge,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=de aar,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bolvasnita,ro
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muros,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yantal,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=springdale,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=paamiut,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tari,pg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san vicente,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=haines junction,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=patacamaya,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=basoko,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tonantins,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fairview,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lethem,gy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kayes,ml
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=abha,sa
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kamenskoye,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sakaiminato,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ust-kut,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=belen,py
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hirara,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tecpan,mx
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=acheng,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sulphur,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa maria,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chiesanuova,sm
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port elizabeth,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hamilton,bm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nishihara,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santo domingo,do
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dakar,sn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=martapura,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=manggar,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=codrington,ag
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tubmanburg,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sitka,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yulara,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ischia,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kloulklubed,pw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=salisbury,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hilo,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=noumea,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tarata,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=coquimbo,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lakes entrance,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=porterville,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=son la,vn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=georgetown,sh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=praya,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ondorhaan,mn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barentsburg,sj
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san carlos de bariloche,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=moanda,ga
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=teya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gladstone,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sangar,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hantsport,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand centre,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port hedland,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gat,ly
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=changli,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lucapa,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nassau,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=siva,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dawlatabad,af
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=namatanai,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atbasar,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pisco,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=east london,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand bank,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shellbrook,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jinchang,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=daru,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=diyarb najm,eg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=constitucion,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=suzun,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sovetskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kodiak,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ewa beach,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san rafael,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luebo,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lebu,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mitsamiouli,km
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kiruna,se
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shimoda,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san cristobal,ec
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atherton,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kadykchan,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hofn,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=naryan-mar,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kuching,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=redmond,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mayo,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jidong,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=walvis bay,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=malakwal,pk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chimbarongo,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sapulpa,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saleaula,ws
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=litovko,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hasaki,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=braganca,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=coos bay,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=temaraia,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yuzhno-yeniseyskiy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ampanihy,mg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=labuhan,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shar,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lewistown,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=camacha,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa catalina,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=portland,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=labrea,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=udachnyy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=srednekolymsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=leningradskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=biak,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=deh rawud,af
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tautira,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=arlit,ne
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=inuvik,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=scottsburgh,za
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pangnirtung,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hammerfest,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alice springs,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mpulungu,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vilyuysk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dikson,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=attawapiskat,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=caravelas,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kruisfontein,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=darhan,mn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bosaso,so
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=plettenberg bay,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=komsomolskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=geraldton,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sodertalje,se
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alyangula,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ust-ishim,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hvammstangi,is
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kaya,bf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=brawley,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sisimiut,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bocholt,be
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=adrar,dz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto del rosario,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=konstantinovka,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santiago,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=orapa,bw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aripuana,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kavieng,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sistranda,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=moranbah,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=naze,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ulundi,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mill valley,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=songjianghe,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kushima,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beloha,mg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bose,cn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sorland,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san quintin,mx
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand river south east,mu
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ishigaki,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=olafsvik,is
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sabang,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beira,mz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tigil,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=petropavlovsk-kamchatskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=birao,cf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ponta delgada,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cairns,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pussi,ee
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=maldonado,uy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chagda,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=loiza,us
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ahipara,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=broome,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lasa,cn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san andres,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=miyang,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=evensk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=granard,ie
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=buchanan,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alta floresta,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=onega,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=preobrazheniye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=erenhot,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=viedma,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sao joao da barra,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=katsuura,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=icusesti,ro
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alofi,nu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ambon,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gidam,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=samana,do
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gwanda,zw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port-gentil,ga
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=brae,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=warqla,dz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marienburg,sr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fairbanks,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=korla,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=karratha,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lezajsk,pl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lorengau,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ferme-neuve,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kerki,tm
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=senno,by
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kalmunai,lk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tacuati,py
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=namibe,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=foki,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zanjan,ir
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=severnoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=antigonish,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=homer,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=viligili,mv
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mangla,pk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kazalinsk,kz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tapaua,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=debre zeyit,et
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marsh harbour,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lata,sb
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port moresby,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=plouzane,fr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand baie,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=el alto,pe
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sterling,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=baykit,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lebedinyy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aden,ye
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=namtsy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chapais,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tidore,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=verkhnyaya sinyachikha,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=anqing,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=havre-saint-pierre,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pathein,mm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hellvik,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=plastun,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=esperance,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=miraflores,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marsala,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nagato,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alexandria,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fuerte olimpo,py
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=klaksvik,fo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ust-maya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yirol,sd
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa cruz del norte,cu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=abomsa,et
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=winnemucca,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=limbang,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mineral wells,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shenzhen,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabialan,ph
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hirado,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kantunilkin,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lengshuijiang,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mentok,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lunca banului,ro
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=noormarkku,fi
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=colesberg,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=batagay-alyta,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=harper,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mandali,iq
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vredendal,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=louisbourg,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vitimskiy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=maragogi,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=svarstad,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=okato,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=leh,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muravlenko,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aginskoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mahibadhoo,mv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taft,ir
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kefalos,gr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=myitkyina,mm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ariquemes,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ambodifototra,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=monrovia,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beyneu,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=paradwip,in
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kamaishi,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=manacapuru,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shambu,et
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=severnyy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jubayl,lb
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kuala terengganu,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pingliang,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bakal,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hesla,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=komyshuvakha,ua
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kalianget,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=boende,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=danvers,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sal rei,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dryden,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kirriemuir,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=wilkie,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rabo de peixe,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sao paulo do potengi,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=andevoranto,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san ramon de la nueva oran,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=la ronge,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=matagami,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=krylovskaya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bandar penggaram,my
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=huaiyin,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tingi,tz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sur,om
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=duvan,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=isangel,vu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=erzin,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=olinda,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tawzar,tn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tucurui,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=narasannapeta,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tumannyy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mundo nuevo,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sorvag,fo
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=samalaeulu,ws
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=robertsport,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mwene-ditu,cd
    <Response [200]>



```python
lat_data = [data.get("coord").get("lat") for data in weather_data]
lng_data = [data.get("coord").get("lon") for data in weather_data]
hum_data = [data.get("main").get("humidity") for data in weather_data]
max_temp_data = [data.get("main").get("temp_max") for data in weather_data]
wind_speed_data = [data.get("wind").get("speed") for data in weather_data]
cloud_data = [data.get("clouds").get("all") for data in weather_data]
city_data = [data.get("name") for data in weather_data]
country_code_data = [data.get("sys").get("country") for data in weather_data]
date_data = [data.get("dt") for data in weather_data]
weather_df = pd.DataFrame({"City":city_data, "Cloudiness":cloud_data, "Country":country_code_data, "Date":date_data,"Humidity":hum_data, "Latitude":lat_data, "Longtitude":lng_data,"Max Temp(F)":max_temp_data,"Wind Speed": wind_speed_data})
```


```python
weather_df["Max Temp(F)"] = weather_df["Max Temp(F)"]*1.8 - 459.67
weather_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Country</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Longtitude</th>
      <th>Max Temp(F)</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Ushuaia</td>
      <td>75</td>
      <td>AR</td>
      <td>1519930800</td>
      <td>66</td>
      <td>-54.81</td>
      <td>-68.31</td>
      <td>53.6000</td>
      <td>7.20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Faanui</td>
      <td>68</td>
      <td>PF</td>
      <td>1519934280</td>
      <td>99</td>
      <td>-16.48</td>
      <td>-151.75</td>
      <td>82.0004</td>
      <td>7.83</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hualmay</td>
      <td>20</td>
      <td>PE</td>
      <td>1519934473</td>
      <td>61</td>
      <td>-11.10</td>
      <td>-77.61</td>
      <td>75.2504</td>
      <td>1.88</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norman Wells</td>
      <td>20</td>
      <td>CA</td>
      <td>1519930800</td>
      <td>75</td>
      <td>65.28</td>
      <td>-126.83</td>
      <td>-18.4000</td>
      <td>1.50</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Innisfail</td>
      <td>80</td>
      <td>AU</td>
      <td>1519934474</td>
      <td>95</td>
      <td>-17.52</td>
      <td>146.03</td>
      <td>74.0804</td>
      <td>1.08</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Save the Dataframe to csv file
weather_df.to_csv("Weather_Data.csv")
```


```python
sns.set(color_codes=True)
sns.regplot(x= "Latitude", y = "Max Temp(F)", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Max Temperature (03/01/2018)")
plt.ylim(-40, 140, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Max Temperature (F)")
plt.savefig("City Latitude vs Max Temperature.png")
```


![png](output_6_0.png)



```python
sns.regplot(x= "Latitude", y = "Humidity", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Humidity (03/01/2018)")
plt.ylim(-20, 120, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Humidity %")
plt.savefig("City Latitude vs Humidity.png")
```


![png](output_7_0.png)



```python
sns.regplot(x= "Latitude", y = "Cloudiness", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Cloudiness (03/01/2018)")
plt.ylim(-20, 120, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Cloudiness %")
plt.savefig("City Latitude vs Cloudiness.png")
```


![png](output_8_0.png)



```python
sns.regplot(x= "Latitude", y = "Wind Speed", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Wind Speed (03/01/2018)")
plt.ylim(-5, 40, 5)
plt.xlim(-90, 90, 20)
plt.ylabel("Wind Speed (mph)")
plt.savefig("City Latitude vs Wind Speed.png")
```


![png](output_9_0.png)



```python
len(weather_data)
```




    500


