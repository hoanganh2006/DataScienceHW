

```python
import requests as req
import json
import openweathermapy as ow
import random
import numpy as np
from citipy import citipy
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
% matplotlib inline
```


```python
# API key and url for Open Weather Map
api_key = "c77d69add01c4b65c6e7966c305d8834"
url = "http://api.openweathermap.org/data/2.5/weather?"
```


```python
location_dict = {}
count = 0
weather_data = []
while count < 500: 
    x = random.uniform(-90.000, 90.000)
    y = random.uniform(-180.000, 180.000)
    location = citipy.nearest_city(x, y)
    city_name = location.city_name
    city_country = location.country_code
    if not city_name in location_dict:
        location_dict.update({city_name: city_country})
        # Build query URL
        query_url = url + "appid=" + api_key + "&q=" + city_name + "," + city_country
        weather = req.get(query_url)
        weather_response = req.get(query_url).json()
        weather_data.append(weather_response)
        try: 
            weather_data.remove({'cod': '404', 'message': 'city not found'})
        except: 
            pass
        count = len(weather_data)
        print(weather)
```

    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saleaula,ws
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mar del plata,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cap malheureux,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=albany,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rikitea,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=castro,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=drayton valley,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bengkulu,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taolanaro,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vao,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sept-iles,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fort nelson,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cape town,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=iqaluit,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=avarua,ck
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aswan,eg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bambous virieux,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sambava,mg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ushuaia,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ponta do sol,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lagoa,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=wajir,ke
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=viedma,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alice springs,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aksarka,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=attawapiskat,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yar-sale,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=olinda,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mount isa,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=eenhana,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ramon,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hima,ug
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=krasnoselkup,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tuktoyaktuk,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marcona,pe
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nikolskoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jalu,ly
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bredasdorp,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=busselton,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=havelock,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=inirida,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mataura,pf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lixourion,gr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=thompson,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atar,mr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=honningsvag,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pisco,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=clyde river,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rassvet,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=illoqqortoormiut,gl
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabuk,sa
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tiksi,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gat,ly
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=whithorn,gb
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=prince rupert,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=el sauzal,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=baracoa,cu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=la macarena,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kapaa,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bluff,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=batu,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mount gambier,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=piacabucu,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=derzhavinsk,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=upernavik,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kaitangata,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ingham,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=new norfolk,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=punta arenas,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=khatanga,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=arinos,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=victoria,sc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hastings,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port alfred,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=george town,ky
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hermanus,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hithadhoo,mv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=roberto payan,co
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port elizabeth,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atuona,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=udachnyy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yefremov,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rungata,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bonthe,sl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa rosa,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tura,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=calabar,ng
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lahij,ye
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=oyama,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sitka,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mys shmidta,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vaini,to
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=murgab,tm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ribeira grande,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hobart,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=arraial do cabo,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=walvis bay,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dikson,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-philippe,re
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san jose,gt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hasaki,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luwuk,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=atasu,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hambantota,lk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint george,bm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barrow,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=te anau,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bulgan,mn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pokrovsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=deputatskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jumla,np
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=general roca,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san carlos de bariloche,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=teguise,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pelym,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=airai,pw
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kruisfontein,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hilo,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pevek,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=moron,mn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ilulissat,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=meyungs,pw
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=forestville,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=longyearbyen,sj
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=coihaique,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ancud,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=samusu,ws
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=palana,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mechanicsville,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mullaitivu,lk
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jamestown,sh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bichena,et
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=awjilah,ly
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grindavik,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=necochea,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila,vu
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=colorines,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=emba,kz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=codrington,ag
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=constitucion,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=geraldton,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san cristobal,ec
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=provideniya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=majene,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kalomo,zm
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yantal,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ondangwa,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dera bugti,pk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port arthur,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nabire,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto escondido,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=riaba,gq
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kurchum,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sioux lookout,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=korla,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=maloshuyka,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yulara,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aksu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=galiwinku,au
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=winneba,gh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nagua,do
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=itarema,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cayenne,gf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=butaritari,ki
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sao filipe,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=honiara,sb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ostrovnoy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=novobelokatay,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sisimiut,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=blyth,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muzquiz,mx
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shebunino,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pangnirtung,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alofi,nu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=qui nhon,vn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=diamantino,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=erenhot,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tasiilaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hamilton,bm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puro,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=niono,ml
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yellowknife,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=estelle,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=crotone,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=uwayl,sd
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=benguela,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=okhotsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chokurdakh,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=east london,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lebu,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lompoc,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=savannah bight,hn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=guerrero negro,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=presidencia roque saenz pena,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vardo,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=utrecht,nl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kushiro,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=snezhnogorsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=anito,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tzaneen,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beinamar,td
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=doctor pedro p. pena,py
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dingle,ie
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zambezi,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=avera,pf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jablah,sy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port lincoln,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kodiak,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ozu,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mahebourg,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=torbay,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bucerias,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=asau,tv
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beloha,mg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=abnub,eg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mezen,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=inhambane,mz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=napasar,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cidreira,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sfantu gheorghe,ro
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kendal,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-augustin,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila franca do campo,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=carutapera,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mansa,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=oistins,bb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tierranueva,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=morehead,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vestmannaeyjar,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=manzanillo,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=alihe,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san patricio,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aksehir,tr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tungkang,tw
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=charqueadas,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=umzimvubu,za
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shwebo,mm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=verkhnevilyuysk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mzimba,mw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=carnarvon,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=amderma,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto ayora,ec
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vallenar,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tiznit,ma
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port augusta,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=emerald,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nizhneyansk,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=broome,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=poso,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ivanava,by
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nuuk,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aripuana,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kiunga,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jiangdu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yanggu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bloemhof,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=belize,bz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabiauea,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=narsaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-pierre,re
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bethel,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bathsheba,bb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rocky mountain house,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dunmore town,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=norman wells,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tumannyy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=georgetown,sh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zhmerynka,ua
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kirakira,sb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kingisepp,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aklavik,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ketchikan,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nanortalik,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sao joao da barra,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kavaratti,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=prainha,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=khunti,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bar harbor,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=port-gentil,ga
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bima,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saskylakh,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=terrak,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=acapulco,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=birjand,ir
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mpanda,tz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gorodishche,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hearst,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=basco,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=todos santos,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cockburn town,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=namestovo,sk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ngunguru,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lolua,tv
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=laurel,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sturgeon falls,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=souillac,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=leshukonskoye,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=phan thiet,vn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mosquera,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=athabasca,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kesan,tr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fort saint john,ca
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kawalu,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=svetlaya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kokstad,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kosh-agach,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tasbuget,kz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sur,om
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=la ronge,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zhuji,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila velha,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=palu,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luganville,vu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ambon,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chuy,uy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muros,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=meulaboh,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=andenes,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=iralaya,hn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=university park,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cabo san lucas,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=largu,ro
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=west odessa,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=umm kaddadah,sd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=esperance,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=adrar,dz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=grand river south east,mu
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=camacha,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=makakilo city,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=phalombe,mw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=visby,se
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luanda,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=qaanaaq,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nara,ml
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kahului,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pimentel,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sangar,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=galveston,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nata,bw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=leningradskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=olpad,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=neiafu,to
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=isangel,vu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=olga,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=faanui,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=poya,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=quthing,ls
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barentsburg,sj
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=iskateley,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=srandakan,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tlanchinol,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=richards bay,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=baraboo,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=renqiu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=skagastrond,is
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=skalistyy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=naze,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=harper,lr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=palabuhanratu,id
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mulchen,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto quijarro,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rawson,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=severo-kurilsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=labuhan,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fuyu,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chinsali,zm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=teahupoo,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=katima mulilo,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=parit raja,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nyurba,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=flinders,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cabadiangan,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=belyy yar,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gacko,ba
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pajapan,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=warren,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=antofagasta,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zhanatas,kz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hadejia,ng
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=igdir,tr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rock sound,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vaitupu,wf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vestmanna,fo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=caraballeda,ve
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bougouni,ml
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=halalo,wf
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nurota,uz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=opuwo,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=the valley,ai
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=darhan,mn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=srednekolymsk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sri aman,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=portland,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=paamiut,gl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=college,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=galeana,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=katsuura,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=salalah,om
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chicama,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ola,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cochabamba,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bahia honda,cu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pangai,to
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cururupu,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=acheng,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=porto novo,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sicuani,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=normandin,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pandan,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=keetmanshoop,na
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=balkanabat,tm
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=caravelas,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fortuna,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chagda,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vuktyl,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=husavik,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chancay,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kilakarai,in
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nema,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cherskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=creston,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=saint-joseph,re
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=quatre cocos,mu
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mabaruma,gy
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nebug,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mayo,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kuching,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=belmonte,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ho,gh
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=valparaiso,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kerrville,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kudahuvadhoo,mv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mergui,mm
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taonan,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=gubkinskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=berlevag,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=energetik,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zhezkazgan,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=laguna,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mattru,sl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=craig,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=butembo,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=solsvik,no
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hirara,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kavieng,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vanimo,pg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taoudenni,ml
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pacific grove,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=huesca,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=merauke,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=poum,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=barbar,sd
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=huicungo,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sabang,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bukama,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kamenskoye,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=stoyba,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lata,sb
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabarqah,tn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=marsh harbour,bs
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=inverell,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=oparino,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=namie,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kadykchan,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=wilmington,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=milkovo,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=rawannawi,ki
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=leiyang,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aktau,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=palmi,it
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san juan del sur,ni
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tabou,ci
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=miracema do tocantins,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=biak,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ituni,gy
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jiaocheng,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chitral,pk
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=dossor,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=lerwick,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=xingyi,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sorvag,fo
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=taltal,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=uporovo,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mandurah,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=puerto leguizamo,co
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=brae,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=imphal,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=van buren,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=maningrida,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hami,cn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san martin,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=evensk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tsihombe,mg
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=falmouth,gb
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=synya,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tuatapere,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=hofn,is
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=northam,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bambanglipuro,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ambilobe,mg
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mutoko,zw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sentyabrskiy,ru
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fare,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=coquimbo,cl
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=luena,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=skjervoy,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=cabra,ph
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mae chan,th
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shu,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vilyuysk,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=vila do maio,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=santa maria,cv
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mudgee,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sandnessjoen,no
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=batagay-alyta,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nantucket,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=anar darreh,af
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=san ramon,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=potosi,bo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=humaita,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=capao da canoa,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=xuddur,so
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=shankargarh,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=half moon bay,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sibu,my
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kloulklubed,pw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=high level,ca
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=talnakh,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=chistogorskiy,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=champagnole,fr
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=mandalgovi,mn
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muzhi,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=esil,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=porbandar,in
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=sobolevo,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=enid,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=umba,ru
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=aflu,dz
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=naftah,tn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=goderich,sl
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tacna,pe
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=upington,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=klaksvik,fo
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=acarau,br
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=pouembout,nc
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=menongue,ao
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=seybaplaya,mx
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=ahipara,nz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=jizan,sa
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=nemuro,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=kijang,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=araguaina,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=karratha,au
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=yunjinghong,cn
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=padang,id
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=los llanos de aridane,es
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=katete,zm
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=praia da vitoria,pt
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tawkar,sd
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=fairbanks,us
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tautira,pf
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=plettenberg bay,za
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=tchibanga,ga
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=guanica,us
    <Response [404]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=beira,mz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=zaysan,kz
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bubaque,gw
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muroto,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=buta,cd
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=omagari,jp
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=natal,br
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=bell ville,ar
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=muscat,om
    <Response [200]>
    http://api.openweathermap.org/data/2.5/weather?appid=c77d69add01c4b65c6e7966c305d8834&q=znamenskoye,ru
    <Response [200]>



```python
lat_data = [data.get("coord").get("lat") for data in weather_data]
lng_data = [data.get("coord").get("lon") for data in weather_data]
hum_data = [data.get("main").get("humidity") for data in weather_data]
max_temp_data = [data.get("main").get("temp_max") for data in weather_data]
wind_speed_data = [data.get("wind").get("speed") for data in weather_data]
cloud_data = [data.get("clouds").get("all") for data in weather_data]
city_data = [data.get("name") for data in weather_data]
country_code_data = [data.get("sys").get("country") for data in weather_data]
date_data = [data.get("dt") for data in weather_data]
weather_df = pd.DataFrame({"City":city_data, "Cloudiness":cloud_data, "Country":country_code_data, "Date":date_data,"Humidity":hum_data, "Latitude":lat_data, "Longtitude":lng_data,"Max Temp(F)":max_temp_data,"Wind Speed": wind_speed_data})
```


```python
weather_df["Max Temp(F)"] = weather_df["Max Temp(F)"]*1.8 - 459.67
weather_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Country</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Longtitude</th>
      <th>Max Temp(F)</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mar del Plata</td>
      <td>8</td>
      <td>AR</td>
      <td>1519928796</td>
      <td>32</td>
      <td>-46.43</td>
      <td>-67.52</td>
      <td>76.1702</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Cap Malheureux</td>
      <td>40</td>
      <td>MU</td>
      <td>1519927200</td>
      <td>83</td>
      <td>-19.98</td>
      <td>57.61</td>
      <td>80.6000</td>
      <td>5.70</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Albany</td>
      <td>88</td>
      <td>AU</td>
      <td>1519928778</td>
      <td>92</td>
      <td>-35.02</td>
      <td>117.88</td>
      <td>55.9652</td>
      <td>2.26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Rikitea</td>
      <td>48</td>
      <td>PF</td>
      <td>1519928774</td>
      <td>99</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>80.8502</td>
      <td>8.21</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Castro</td>
      <td>20</td>
      <td>CL</td>
      <td>1519928786</td>
      <td>75</td>
      <td>-42.48</td>
      <td>-73.76</td>
      <td>64.7852</td>
      <td>1.11</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set(color_codes=True)
sns.regplot(x= "Latitude", y = "Max Temp(F)", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Max Temperature (03/01/2018)")
plt.ylim(-40, 140, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Max Temperature (F)")
plt.savefig("City Latitude vs Max Temperature.png")
```


![png](output_5_0.png)



```python
sns.regplot(x= "Latitude", y = "Humidity", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Humidity (03/01/2018)")
plt.ylim(-20, 120, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Humidity %")
plt.savefig("City Latitude vs Humidity.png")
```


![png](output_6_0.png)



```python
sns.regplot(x= "Latitude", y = "Cloudiness", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Cloudiness (03/01/2018)")
plt.ylim(-20, 120, 20)
plt.xlim(-90, 90, 20)
plt.ylabel("Cloudiness %")
plt.savefig("City Latitude vs Cloudiness.png")
```


![png](output_7_0.png)



```python
sns.regplot(x= "Latitude", y = "Wind Speed", data = weather_df, color = 'darkblue',fit_reg=False)
plt.title("City Latitude vs. Wind Speed (03/01/2018)")
plt.ylim(-5, 40, 5)
plt.xlim(-90, 90, 20)
plt.ylabel("Wind Speed (mph)")
plt.savefig("City Latitude vs Wind Speed.png")
```


![png](output_8_0.png)



```python
len(weather_data)
```




    500


